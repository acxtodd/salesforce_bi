"""
Sync Lambda Function
Writes chunks to S3 as individual text files with metadata for Bedrock Knowledge Base ingestion.
"""
import json
import boto3
import os
from datetime import datetime
from typing import Dict, Any, List

# Initialize AWS clients
s3_client = boto3.client('s3')
cloudwatch_client = boto3.client('cloudwatch')

# Environment variables
DATA_BUCKET = os.environ.get('DATA_BUCKET')


def write_chunk_to_s3(chunk: Dict[str, Any], bucket: str) -> str:
    """
    Write a single chunk to S3 as .txt and .metadata.json
    
    Args:
        chunk: Chunk dictionary
        bucket: S3 bucket name
    
    Returns:
        S3 key prefix
    """
    chunk_id = chunk["id"]
    # Sanitize ID for S3 key if needed, but slashes are fine
    # ID format: sobject/recordId/chunk-index
    # We want S3 key: chunks/sobject/recordId/chunk-index.txt
    
    s3_base_key = f"chunks/{chunk_id}"
    s3_txt_key = f"{s3_base_key}.txt"
    s3_meta_key = f"{s3_base_key}.txt.metadata.json"
    
    # Write text content
    text_content = chunk["text"]
    s3_client.put_object(
        Bucket=bucket,
        Key=s3_txt_key,
        Body=text_content.encode('utf-8'),
        ContentType='text/plain'
    )
    
    # Write metadata
    metadata = chunk.get("metadata", {})
    
    # Ensure metadataValues are strings/numbers/booleans/lists of strings
    # Bedrock KB metadata requirements: flat JSON or simple structure
    # Actually, .metadata.json expects: {"metadataAttributes": {...}}
    
    bedrock_metadata = {
        "metadataAttributes": metadata
    }
    
    s3_client.put_object(
        Bucket=bucket,
        Key=s3_meta_key,
        Body=json.dumps(bedrock_metadata).encode('utf-8'),
        ContentType='application/json'
    )
    
    return s3_base_key


def emit_pipeline_metrics(chunks: List[Dict[str, Any]]):
    """
    Emit pipeline completion metrics to CloudWatch.
    """
    try:
        sobject_counts = {}
        for chunk in chunks:
            sobject = chunk.get('metadata', {}).get('sobject', 'Unknown')
            sobject_counts[sobject] = sobject_counts.get(sobject, 0) + 1
        
        for chunk in chunks:
            metadata = chunk.get('metadata', {})
            cdc_commit_timestamp = metadata.get('_cdc_commit_timestamp')
            
            if cdc_commit_timestamp:
                commit_time = datetime.fromtimestamp(cdc_commit_timestamp / 1000.0)
                sync_time = datetime.utcnow()
                end_to_end_lag_ms = int((sync_time - commit_time).total_seconds() * 1000)
                sobject = metadata.get('sobject', 'Unknown')
                
                cloudwatch_client.put_metric_data(
                    Namespace='SalesforceAISearch/Ingestion',
                    MetricData=[{
                        'MetricName': 'EndToEndLag',
                        'Value': end_to_end_lag_ms,
                        'Unit': 'Milliseconds',
                        'Dimensions': [{'Name': 'SObject', 'Value': sobject}, {'Name': 'Stage', 'Value': 'EndToEnd'}]
                    }]
                )
        
        metric_data = []
        for sobject, count in sobject_counts.items():
            metric_data.append({
                'MetricName': 'ChunksSynced',
                'Value': count,
                'Unit': 'Count',
                'Dimensions': [{'Name': 'SObject', 'Value': sobject}]
            })
        
        if metric_data:
            cloudwatch_client.put_metric_data(
                Namespace='SalesforceAISearch/Ingestion',
                MetricData=metric_data
            )
            
        print(f"Synced chunks by object: {sobject_counts}")
        
    except Exception as e:
        print(f"Error emitting pipeline metrics: {str(e)}")


def lambda_handler(event, context):
    """
    Write embedded chunks to S3 in Bedrock KB format (Text + Metadata).
    """
    try:
        chunks = event.get("embeddedChunks", [])
        
        if not chunks:
            print("No chunks to sync")
            return {
                "s3Bucket": DATA_BUCKET,
                "chunkCount": 0,
                "success": True
            }
        
        if not DATA_BUCKET:
            raise ValueError("DATA_BUCKET environment variable not set")
        
        print(f"Syncing {len(chunks)} chunks to S3")
        
        # Write each chunk to S3
        for chunk in chunks:
            write_chunk_to_s3(chunk, DATA_BUCKET)
        
        # Emit metrics
        emit_pipeline_metrics(chunks)
        
        return {
            "s3Bucket": DATA_BUCKET,
            "chunkCount": len(chunks),
            "success": True
        }
    
    except Exception as e:
        print(f"Error in lambda_handler: {str(e)}")
        raise